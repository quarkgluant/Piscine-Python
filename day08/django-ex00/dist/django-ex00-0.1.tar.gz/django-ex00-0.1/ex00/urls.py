from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^ex00$', views.home, name='home'),
]
